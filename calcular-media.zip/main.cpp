/*Calcula a media - C++ */

#include <iostream>

using namespace std;int main()
{
    float n1, n2, n3, media;
    
    printf("Digite a primeira nota:");
    scanf("%f", &n1);
    
    printf("Digite a segunda nota:");
    scanf("%f", &n2);
    
    printf("Digite a terceira nota");
    scanf("%f", &n3);
    
    media = (n1 + n2 + n3) /3;
    printf("O resultado é: %f", media);
    
}